# -*- mode: shell-script -*-
# Copyright (C) 2009-2012 David Bird (Coova Technologies) <support@coova.com>
# 
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#  
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#  
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

paypal_redirect() {

    echo
}

paypal_verify() {
    echo
}


#
#
#<form method=post action="https://www.paypal.com/cgi-bin/webscr">
#<input type="hidden" name="cmd" value="_notify-synch">
#<input type="hidden" name="tx" value="TransactionID">
#<input type="hidden" name="at" value="YourIdentityToken">
#<input type="submit" value="PDT">
#</form> 
#
#SUCCESS
#first_name=Jane+Doe
#last_name=Smith
#payment_status=Completed
#payer_email=janedoesmith%40hotmail.com
#payment_gross=3.99
#mc_currency=USD
#custom=For+the+purchase+of+the+rare+book+Green+Eggs+%26+Ham
#... 
#
